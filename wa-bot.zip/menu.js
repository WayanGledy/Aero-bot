async function menu(sock, jid) {
    const menuText = `
    *Menu Bot*
    1. .ttvideo <link> - Download TikTok video
    2. .readmore text1|text2 - Create readmore message
    3. .menu - Show this menu
    `;
    await sock.sendMessage(jid, { text: menuText });
}

module.exports = { menu };