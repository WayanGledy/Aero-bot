const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const P = require('pino');
const readline = require('readline');
const { handleTikTokVideo } = require('./lib/tiktok');
const { handleReadMore } = require('./lib/readmore');
const { prefix, commands } = require('./config');
const { menu } = require('./menu');

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const { version, isLatest } = await fetchLatestBaileysVersion();
    console.log(`using WA v${version.join('.')}, isLatest: ${isLatest}`);

    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        auth: state
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut);
            console.log('connection closed due to ', lastDisconnect.error, ', reconnecting ', shouldReconnect);
            if (shouldReconnect) {
                startBot();
            }
        } else if (connection === 'open') {
            console.log('opened connection');
        }
    });

    // Listen for messages
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.message) return;
        const messageType = Object.keys(msg.message)[0];
        const messageContent = msg.message.conversation || msg.message[messageType].caption || '';

        // Command handling
        if (messageContent.startsWith(prefix)) {
            const args = messageContent.slice(prefix.length).trim().split(/ +/);
            const command = args.shift().toLowerCase();

            if (commands.includes(command)) {
                switch (command) {
                    case 'ttvideo':
                        const url = args[0];
                        await handleTikTokVideo(sock, msg.key.remoteJid, url);
                        break;
                    case 'readmore':
                        const parts = args.join(' ').split('|');
                        await handleReadMore(sock, msg.key.remoteJid, parts);
                        break;
                    case 'menu':
                        await menu(sock, msg.key.remoteJid);
                        break;
                }
                console.log(`Command: ${command} from: ${msg.key.remoteJid} at: ${new Date().toISOString()}`);
            }
        }
    });

    // Request user's phone number for pairing
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question('Masukkan nomor WhatsApp anda awali dengan +62: ', (number) => {
        console.log(`Ini adalah pairing kode anda: ${state.creds.me.id}`);
        rl.close();
    });
}

startBot();