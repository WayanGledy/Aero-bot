module.exports = {
    prefix: '.',
    commands: ['ttvideo', 'readmore', 'menu']
};